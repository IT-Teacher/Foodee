package uz.it_teacher.foodee.model

class Ingredient(
    var name: String,
    var img: Int,
    var price: String
):java.io.Serializable